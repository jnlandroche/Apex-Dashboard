export type ApexPlatform = 'PC' | 'X1' | 'PS4' | 'SWITCH';
export type ApexProfile = { uid?: string; name: string; platform: ApexPlatform; level?: number; avatar?: string; rankName?: string; rankScore?: number; global?: any; legends?: any[]; raw: any };

const API_BASE = 'https://api.mozambiquehe.re';

export async function fetchApexProfile(playerName: string, platform: ApexPlatform, apiKey?: string): Promise<ApexProfile> {
  const key = apiKey || process.env.APEX_API_KEY;
  if (!key) throw new Error('Missing APEX_API_KEY');
  const url = `${API_BASE}/bridge?auth=${encodeURIComponent(key)}&player=${encodeURIComponent(playerName)}&platform=${platform}`;
  const res = await fetch(url, { cache: 'no-store' });
  const data = await res.json();
  if (!res.ok || data?.Error || data?.error) throw new Error(data?.Error || data?.error || 'Apex API request failed');
  const global = data.global || {};
  const rank = global.rank || {};
  return { uid: global.uid, name: global.name || playerName, platform, level: global.level, avatar: global.avatar, rankName: rank.rankName, rankScore: rank.rankScore, global, legends: data.legends?.all ? Object.values(data.legends.all) : [], raw: data };
}

export function extractMetrics(profile: ApexProfile) {
  const g = profile.global || {};
  return {
    level: Number(g.level || 0),
    kills: Number(g.kills?.value || g.kills || 0),
    damage: Number(g.damage?.value || g.damage || 0),
    kd: Number(g.kd?.value || g.kd || 0),
    rank_name: profile.rankName || 'Unknown',
    rank_score: Number(profile.rankScore || 0),
    avatar: profile.avatar || null,
  };
}
