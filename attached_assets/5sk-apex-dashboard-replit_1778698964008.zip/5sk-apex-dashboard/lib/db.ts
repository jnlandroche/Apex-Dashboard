import { promises as fs } from 'fs';
import path from 'path';
import { randomUUID } from 'crypto';

export type Player = {
  id: string;
  name: string;
  platform: string;
  uid?: string;
  avatar?: string | null;
  active: boolean;
  created_at: string;
};

export type StatSnapshot = {
  id: string;
  player_id: string;
  captured_at: string;
  rank_name?: string;
  rank_score?: number;
  level?: number;
  kills?: number;
  damage?: number;
  kd?: number;
  avatar?: string | null;
  raw?: any;
};

type DB = { players: Player[]; stat_snapshots: StatSnapshot[] };

const dbPath = path.join(process.cwd(), '.data', '5sk-db.json');

async function ensureDb(): Promise<DB> {
  await fs.mkdir(path.dirname(dbPath), { recursive: true });
  try {
    const raw = await fs.readFile(dbPath, 'utf8');
    return JSON.parse(raw) as DB;
  } catch {
    const starter: DB = { players: [], stat_snapshots: [] };
    await fs.writeFile(dbPath, JSON.stringify(starter, null, 2));
    return starter;
  }
}

async function saveDb(db: DB) {
  await fs.mkdir(path.dirname(dbPath), { recursive: true });
  await fs.writeFile(dbPath, JSON.stringify(db, null, 2));
}

export async function getPlayers() {
  const db = await ensureDb();
  return [...db.players].sort((a, b) => a.created_at.localeCompare(b.created_at));
}

export async function getActivePlayers() {
  const players = await getPlayers();
  return players.filter(p => p.active);
}

export async function upsertPlayer(input: Omit<Player, 'id' | 'created_at' | 'active'> & { active?: boolean }) {
  const db = await ensureDb();
  const existing = db.players.find(p => p.name.toLowerCase() === input.name.toLowerCase() && p.platform === input.platform);
  if (existing) {
    Object.assign(existing, { ...input, active: input.active ?? true });
    await saveDb(db);
    return existing;
  }
  const player: Player = { id: randomUUID(), created_at: new Date().toISOString(), active: input.active ?? true, ...input };
  db.players.push(player);
  await saveDb(db);
  return player;
}

export async function addSnapshot(input: Omit<StatSnapshot, 'id' | 'captured_at'> & { captured_at?: string }) {
  const db = await ensureDb();
  const snap: StatSnapshot = { id: randomUUID(), captured_at: input.captured_at || new Date().toISOString(), ...input };
  db.stat_snapshots.push(snap);
  // keep the local file lean on Replit
  if (db.stat_snapshots.length > 2500) db.stat_snapshots = db.stat_snapshots.slice(-2500);
  await saveDb(db);
  return snap;
}

export async function getSnapshots(limit = 250) {
  const db = await ensureDb();
  return [...db.stat_snapshots]
    .sort((a, b) => b.captured_at.localeCompare(a.captured_at))
    .slice(0, limit)
    .map(s => ({ ...s, players: { name: db.players.find(p => p.id === s.player_id)?.name || 'Unknown' } }));
}

export async function getLatestStats() {
  const db = await ensureDb();
  const latestByPlayer = new Map<string, StatSnapshot>();
  for (const s of [...db.stat_snapshots].sort((a, b) => b.captured_at.localeCompare(a.captured_at))) {
    if (!latestByPlayer.has(s.player_id)) latestByPlayer.set(s.player_id, s);
  }
  const stats = db.players.filter(p => p.active).map(p => {
    const s = latestByPlayer.get(p.id);
    return {
      player_id: p.id,
      name: p.name,
      platform: p.platform,
      avatar: s?.avatar || p.avatar || null,
      captured_at: s?.captured_at || null,
      rank_name: s?.rank_name || '—',
      rank_score: s?.rank_score || 0,
      level: s?.level || 0,
      kills: s?.kills || 0,
      damage: s?.damage || 0,
      kd: s?.kd || 0,
    };
  });
  return { players: db.players.filter(p => p.active), stats };
}
