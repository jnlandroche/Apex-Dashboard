export function clsx(...parts: Array<string | false | null | undefined>) { return parts.filter(Boolean).join(' '); }
export function fmt(n?: number | null) { return typeof n === 'number' ? Intl.NumberFormat('en-US').format(Math.round(n)) : '—'; }
