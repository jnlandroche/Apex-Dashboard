import { StatCard } from '@/components/StatCard';
import { RankBar, SharePie } from '@/components/Charts';
import { fmt } from '@/lib/utils';
import { getLatestStats } from '@/lib/db';
import { PollButton } from '@/components/PollButton';
async function getData(){ return await getLatestStats(); }
export default async function Dashboard(){
  const data = await getData();
  const stats = data.stats || [];
  const topRank = [...stats].sort((a,b)=>(b.rank_score||0)-(a.rank_score||0))[0];
  const topKills = [...stats].sort((a,b)=>(b.kills||0)-(a.kills||0))[0];
  const totalKills = stats.reduce((a:any,b:any)=>a+(b.kills||0),0);
  const totalDamage = stats.reduce((a:any,b:any)=>a+(b.damage||0),0);
  const chartData = stats.map((s:any)=>({name:s.name, rank_score:s.rank_score||0,kills:s.kills||0,damage:s.damage||0}));
  return <div className="space-y-8"><header className="rounded-3xl bg-gradient-to-r from-slate-950 via-slate-900 to-cyan-950 p-8 ring-1 ring-white/10"><div className="text-sm uppercase tracking-[.35em] text-neon">5SK Apex Legends</div><h1 className="mt-3 text-4xl font-black md:text-6xl">Squad Command Center</h1><p className="mt-3 max-w-3xl text-slate-300">Track ranked progression, compare teammates, and build weekly MVP summaries from Apex Legends API snapshots.</p><div className="mt-5"><PollButton/></div></header><section className="grid gap-4 md:grid-cols-4"><StatCard label="Players Tracked" value={stats.length}/><StatCard label="Top Ranked" value={topRank?.name || '—'} hint={topRank?.rank_name}/><StatCard label="Squad Kills" value={fmt(totalKills)}/><StatCard label="Squad Damage" value={fmt(totalDamage)}/></section><section className="grid gap-6 xl:grid-cols-2"><div className="glass rounded-3xl p-6"><h2 className="text-xl font-bold">Rank Score by Player</h2><RankBar data={chartData}/></div><div className="glass rounded-3xl p-6"><h2 className="text-xl font-bold">Kill Share</h2><SharePie data={chartData}/></div></section><section className="glass rounded-3xl p-6"><h2 className="mb-4 text-xl font-bold">Current Squad Snapshot</h2><div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead className="text-slate-400"><tr><th className="p-3">Player</th><th>Rank</th><th>RP</th><th>Level</th><th>Kills</th><th>Damage</th><th>Last Update</th></tr></thead><tbody>{stats.map((s:any)=><tr key={s.player_id} className="border-t border-white/10"><td className="p-3 font-semibold text-white">{s.name}</td><td>{s.rank_name||'—'}</td><td>{fmt(s.rank_score)}</td><td>{fmt(s.level)}</td><td>{fmt(s.kills)}</td><td>{fmt(s.damage)}</td><td>{s.captured_at ? new Date(s.captured_at).toLocaleString() : '—'}</td></tr>)}</tbody></table></div></section></div>
}
