import { NextResponse } from 'next/server';
import { fetchApexProfile, extractMetrics } from '@/lib/apex';
import { addSnapshot, getPlayers, upsertPlayer } from '@/lib/db';

export async function GET() {
  return NextResponse.json(await getPlayers());
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const name = String(body.name || '').trim();
    const platform = body.platform || 'PC';
    const apiKey = body.apiKey || process.env.APEX_API_KEY;
    if (!name) return NextResponse.json({ error: 'Player name required' }, { status: 400 });
    const profile = await fetchApexProfile(name, platform, apiKey);
    const player = await upsertPlayer({ name: profile.name, platform, uid: profile.uid, avatar: profile.avatar, active: true });
    const metrics = extractMetrics(profile);
    await addSnapshot({ player_id: player.id, ...metrics, raw: profile.raw });
    return NextResponse.json({ player, profile });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
