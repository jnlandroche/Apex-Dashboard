import { NextResponse } from 'next/server';
import { getLatestStats } from '@/lib/db';
export async function GET() {
  return NextResponse.json(await getLatestStats());
}
