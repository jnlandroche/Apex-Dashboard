import { NextResponse } from 'next/server';
import { fetchApexProfile, extractMetrics } from '@/lib/apex';
import { addSnapshot, getActivePlayers } from '@/lib/db';

export async function POST() {
  const players = await getActivePlayers();
  const results: any[] = [];
  for (const p of players) {
    try {
      const profile = await fetchApexProfile(p.name, p.platform as any);
      const metrics = extractMetrics(profile);
      await addSnapshot({ player_id: p.id, ...metrics, raw: profile.raw });
      results.push({ name: p.name, status: 'updated' });
    } catch (e: any) {
      results.push({ name: p.name, status: 'error', error: e.message });
    }
  }
  return NextResponse.json({ ok: true, results });
}
