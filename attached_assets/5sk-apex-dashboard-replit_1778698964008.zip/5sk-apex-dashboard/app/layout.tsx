import './globals.css';
import { Nav } from '@/components/Nav';
export const metadata = { title: '5SK Apex Dashboard', description: 'Squad analytics for Apex Legends' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body><Nav/><main className="min-h-screen p-4 lg:ml-64 lg:p-8">{children}</main></body></html>}
