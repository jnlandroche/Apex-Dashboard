import type { Config } from 'tailwindcss';
const config: Config = {content:['./app/**/*.{ts,tsx}','./components/**/*.{ts,tsx}'],theme:{extend:{colors:{bg:'#070A12',panel:'#0D1324',line:'#1E293B',neon:'#22D3EE',danger:'#F43F5E',gold:'#F59E0B'}}},plugins:[]};
export default config;
