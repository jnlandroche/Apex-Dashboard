'use client';
import { useState } from 'react';
export function PollButton() {
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  async function poll() {
    setBusy(true); setMsg('Refreshing squad stats...');
    const res = await fetch('/api/poll', { method: 'POST' });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) { setMsg(data.error || 'Refresh failed'); return; }
    setMsg(`Updated ${data.results?.filter((r:any)=>r.status==='updated').length || 0} player(s). Refresh the page to see latest stats.`);
  }
  return <div className="flex flex-col gap-2 sm:flex-row sm:items-center"><button onClick={poll} disabled={busy} className="rounded-xl bg-cyan-400 px-4 py-3 font-bold text-slate-950 disabled:opacity-60">{busy ? 'Refreshing...' : 'Refresh Stats Now'}</button>{msg && <span className="text-sm text-slate-300">{msg}</span>}</div>;
}
