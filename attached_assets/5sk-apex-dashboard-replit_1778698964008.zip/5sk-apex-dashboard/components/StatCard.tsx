export function StatCard({ label, value, hint }: { label: string; value: string | number; hint?: string }) {
  return <div className="glass rounded-2xl p-5"><p className="text-sm text-slate-400">{label}</p><div className="mt-2 text-3xl font-bold tracking-tight">{value}</div>{hint && <p className="mt-2 text-xs text-slate-500">{hint}</p>}</div>;
}
