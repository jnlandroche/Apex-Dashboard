'use client';
import { useState } from 'react';
export function AddPlayerForm(){
 const [name,setName]=useState(''); const [platform,setPlatform]=useState('PC'); const [apiKey,setApiKey]=useState(''); const [msg,setMsg]=useState(''); const [busy,setBusy]=useState(false);
 async function submit(e:React.FormEvent){e.preventDefault(); setBusy(true); setMsg('Validating player...');
  const res=await fetch('/api/players',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,platform,apiKey:apiKey||undefined})});
  const data=await res.json(); setBusy(false); if(!res.ok){setMsg(data.error||'Failed'); return;} setMsg(`Added ${data.player.name}. Refresh dashboard to view stats.`); setName('');
 }
 return <form onSubmit={submit} className="mt-4 grid gap-3 md:grid-cols-4"><input value={name} onChange={e=>setName(e.target.value)} placeholder="Apex username" className="rounded-xl bg-slate-950 p-3 ring-1 ring-white/10"/><select value={platform} onChange={e=>setPlatform(e.target.value)} className="rounded-xl bg-slate-950 p-3 ring-1 ring-white/10"><option value="PC">PC</option><option value="X1">Xbox</option><option value="PS4">PlayStation</option><option value="SWITCH">Switch</option></select><input value={apiKey} onChange={e=>setApiKey(e.target.value)} placeholder="Optional API key" className="rounded-xl bg-slate-950 p-3 ring-1 ring-white/10"/><button disabled={busy} className="rounded-xl bg-cyan-400 px-4 py-3 font-bold text-slate-950 disabled:opacity-60">{busy?'Checking...':'Validate & Add'}</button>{msg && <p className="md:col-span-4 text-sm text-slate-300">{msg}</p>}</form>
}
