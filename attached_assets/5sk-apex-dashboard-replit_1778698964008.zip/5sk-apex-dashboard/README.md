# 5SK Apex Dashboard — Replit One-Click Version

This is the easiest version of the 5SK Apex tracker. It removes GitHub, Supabase, and Vercel from the setup.

## Fast setup

1. Go to Replit.
2. Create a new Repl by importing/uploading this ZIP.
3. Open **Secrets**.
4. Add:

```env
APEX_API_KEY=your_apexlegendsapi_key
CRON_SECRET=anything-random-optional
```

5. Click **Run**.
6. Open the web preview.
7. Go to **Players** and add:
   - Daveskey
   - Optics
   - Cobra
8. Go back to **Dashboard** and click **Refresh Stats Now**.
9. Click **Deploy** in Replit when you want a public URL.

## How data is stored

This version stores players and stat snapshots locally in:

```text
.data/5sk-db.json
```

No external database is required.

## What it tracks

- Apex player validation
- Current rank / RP snapshot
- Level
- Kills
- Damage
- Squad leaderboard
- Latest stat snapshots
- Snapshot history over time

## Important limitation

Apex APIs usually provide stat snapshots rather than perfect match-by-match history. This app stores snapshots over time and uses them to build trends.

## Manual refresh

Use the **Refresh Stats Now** button on the dashboard.

## Optional scheduled refresh

If you want a scheduled refresh later, call this endpoint from an uptime monitor or Replit scheduled job:

```text
/api/cron/poll?secret=YOUR_CRON_SECRET
```
